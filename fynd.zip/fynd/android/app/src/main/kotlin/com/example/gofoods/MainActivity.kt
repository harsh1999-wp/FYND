package com.example.gofoods

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'package:flutter/material.dart';

Color redcolor = const Color(0xff08CB5A);
Color darkred = const Color(0xff08CB5A);

Color white =   Colors.white;
Color darkwhite =   const Color(0xff2D2D3A);

Color bgcolor =   const Color(0xff2D2D3A);
Color darkbgcolor =  const Color(0xfff8f8fa);

Color blackcolor =    Colors.white;
Color darkblackcolor =   Colors.black;

Color grey =   Colors.grey;
Color darkgrey =   Colors.grey;

Color starcolor =   const Color(0xfff29a4c);
Color darkstarcolor =  const Color(0xfff29a4c);

Color bottomcolor = const Color(0xffFCFCFC);
Color darkbottomcolor =  const   Color(0xff2D2D3A);

Color darkbgfildcolor =      Colors.white;
Color bgfildcolor =  const   Color(0xff3d3d4e);


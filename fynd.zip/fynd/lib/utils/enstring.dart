class LanguageEn {
  static String get getstarted => "Get Started";

  static String get findyourfavoritefoodanytime =>
      "Find your favorite food anytime from\nour existing location easily";

  static String get findyourfavoritefood => "Find Your Favorite Food";

  static String get ourdeliveryman =>
      "Our delivery man deliver the food to\nyou home so fast";

  static String get hotdeliveryhome => "Hot Delivery to Home";

  static String get adresslineone => "Address Line 1";

  static String get adresslinetwo => "Address Line 2";

  static String get selects  => "Make default shipping address";

  static String get deliveryadds   => "Address Update";

  static String get atul   => "Atul cake Shop";

  static String get sevenchess   => "Seven Chees";

  static String get derryfresh   => "Derry Fresh";

  static String get successorder => "Success Order";

  static String get donzs => "Donz's";

  static String get calzne => "Calzne Pizza";

  static String get youreceivethe =>
      "You'll receive the great food within a\nfew minutes";

  static String get receivethegreatfood => "Receive the Great Food";

  static String get dontreceivedthecode => "Dont't received the code?";

  static String get verificationcodeotp => "Verification codes OTP";

  static String get averificationcodeshasbeensendto =>
      "A verification codes has been send to";

  static String get wellcomethusinh => "WelCome! ThuSinh";

  static String get darkmode => "Dark Mode";

  static String get loream =>
      "Traditionally, Lorem Ipsum was used for specimen papers in the print industry. Then, as the industry developed, the text began to show up in transfer sheets and on word processors.";

  static String get pleaseenteryourphonenumber =>
      "Please enter your phone number\ntousing Carr services";

  static String get enteryourpassword => "Enter Your Password";

  static String get next => "Next";

  static String get price => "Price";

  static String get apply => "Apply";

  static String get confirm => "Confirm";

  static String get bronx => "Bronx";

  static String get brooklyn => "Brooklyn";

  static String get samara => "Samara river city";

  static String get manhattan => "Manhattan";

  static String get staten => "Staten lsland";

  static String get nearme => "Near me";

  static String get home => "Home";

  static String get signinwithfaceid => "Sign in with Face ID";

  static String get forgotpassword => "Forgot Password";

  static String get forgot => "Forget";

  static String get passwordreset => "Password reset!";

  static String get continuewithfaceid => "Continue With Face ID";

  static String get usefaceidtounlockcarr => "Use Face ID to unlock Carr";

  static String get cancel => "Cancel";

  static String get completeorder => "Complete Order";

  static String get enableyourlocation => "Enable your location";

  static String get freeshipwithin =>
      "Freeship within 5km: Enter code Freeship";

  static String get tosearchforthebest =>
      "To search for the best nearby driver, we\nwant to know your current location";

  static String get usecurrentlocation => "Use current location";

  static String get offonallmenuitems => "30% off on all menu items";

  static String get skipfornow => "Skip for now";

  static String get deliveryto => "Delivery to";

  static String get hanoivietname => "Hanoi,Vietname";

  static String get searchfordish => "Search for dish or restaurant";

  static String get popularnearyou => "Popular Near You";

  static String get viewmore => "View more";

  static String get burgerking => "Burger King - Thai Ha";

  static String get burgerkings => "Burger King";

  static String get monginis => "Monginis";

  static String get mayo => "Mayo Burger";

  static String get westernburger => "Western cuisine, Fast Food, Burger";

  static String get westernburgerfast => "Western cuisine, Fast\nFood, Burger";

  static String get explorecategories => "Explore Categories";

  static String get showall => "Show all";

  static String get createaccount => "Create Account";

  static String get alredyhaveaccount => "Already have an account?";

  static String get food => "Food";

  static String get recommended => "Recommended";

  static String get orderfood =>
      "Order food delivery online\nfrom hundreds of\nrestaurants";

  static String get nearbyrestorent => "Near by Restorent";

  static String get showthemyoucare =>
      "Show them you care. We're\nready to deliver to your\nloved one.";

  static String get savorbread => "McDonalds";

  static String get cocahouse => "StarBucks";

  static String get banhmimilk => "Banh mi, Milk Tea, Snacks";

  static String get vietnamese => "Vietnamese cuisine, Chicken rice";

  static String get delivery => "Delivery";

  static String get menu => "Menu";

  static String get review => "Review";

  static String get idle => "Pizza";

  static String get juice => "Dessert";

  static String get sup => "Drink";

  static String get pizza => "Pizza";

  static String get pasta => "Pasta&Rice";

  static String get drink => "Drink";

  static String get location => "Location";

  static String get filterby => "Filter by";

  static String get special => "Special";

  static String get cheesy => "Cheesy Bites Trio Shrimp";

  static String get shrimponion =>
      "Shrimp, onion, red capsicum,\npineapple, black olive, parsley";

  static String get myorder => "My Order";

  static String get margarita => "Margarita";

  static String get bbqbacon => "BBQ Bacon\nCheese Burger";

  static String get qty => "Qty";

  static String get harrydaniels => "Harry Daniels";

  static String get adnew => "Add new";

  static String get choiceofsize => "Choice of size";

  static String get choiceoftopping => "Choice of topping";

  static String get orderconfirmation => "Order Confirmation";

  static String get yourorder => "Your order";

  static String get steakbeet => "Steak Beet";

  static String get pieces => "2 pieces";

  static String get hambuger => "Hambuger hot";

  static String get subtotal => "Subtotal 12 iteam";

  static String get subtotals => "Subtotal";

  static String get deliverycharges => "Delivery charges";

  static String get total => "Total";

  static String get payment => "Payment";

  static String get payments => "Payment Methods";

  static String get cash => "Cash";

  static String get cardvisa => "Card Visa";

  static String get cardmaster => "Card Master";

  static String get yummywallet => "Go Foods Wallet";

  static String get checking => "Order Placed";

  static String get ordersuccess => "Order Placed Successfully";

  static String get pleasewaitafewminute =>
      "Please wait a few minutes. We are looking for a\ndrive for you";

  static String get close => "Close";

  static String get enteryourphonenumber => "Enter your phone number";

  static String get pleaseenterphonenumber =>
      "Please enter phone number\nto using Carr service";

  static String get loginwithphonenumber => "Login with phone number";

  static String get history => "History";

  static String get wewillsend =>
      "We will send the authentication code to\nthe phone number you entered.\nDo you want continue?";

  static String get complete => "Complete";

  static String get myprofile => "My Profile";

  static String get myporder => "My Order";

  static String get profilesetting => "Profile settings";

  static String get favoriterestaurant => "Favorite restaurant";

  static String get discountsandpromocodes => "Discounts and promocodes";

  static String get notifications => "Notifications";

  static String get youhavepoints => "You have 7 119 points";

  static String get invitefriend => "Invite Friend";

  static String get done => "Done";

  static String get save => "Save";

  static String get successfully => 'Successfully booked. You will rece...';

  static String get yesterday => 'Yesterday at 10:00 AM';

  static String get lockdown => 'Lockdown: Enjoy upto 70% off...';

  static String get mar => '12 Mar 2021 at 10:00 PM';

  static String get wayorder => 'Order is on the way.';

  static String get mar1 => '09 Mar 2021 at 11:35 AM';

  static String get prepared => 'Order is being prepared.';

  static String get mar2 => '20 Feb 2021 at 10:00 AM';

  static String get discount => 'Grab now New Year 2021 discount.';

  static String get discounts => 'Discount';

  static String get mar3 => '31 Dec 2020 at 11:00 PM';

  static String get statuss => 'Delivery Status';

  static String get t1 => '09 Mar 2021 at 03:00 PM';

  static String get t2 => '09 Mar 2021';

  static String get t3 => '11 Mar 2021';

  static String get t4 => '11 Mar 2021 at 10:00 AM';

  static String get accept => 'Order is accepted.';

  static String get being => 'Order is being prepared.';

  static String get willbe => 'Order will be delivered soon.';

  static String get ways => 'Order is on the way.';

  static String get orderfroam => 'Ordered From:';

  static String get aboutus => 'About us';

  static String get faq => 'FAQs';

  static String get teamsandcontiotion => 'Teams & Condition';

  static String get helpcenter => 'Help Center';

  static String get logout => 'Log Out';

  static String get milkshake => 'Milk Shake';

  static String get omelette => 'Omelette';

  static String get tomatosup => 'Tomato Sup';

  static String get shake => 'Shake';

  static String get fruitdish => 'Fruit Dish';

  static String get dalfry => 'Dal Fry';

  static String get burgerkingg => 'BurgerKing';

  static String get finddeals =>
      'Find deals, free delivery,\nand more from our\nrestaurant partners.';

  static String get papajohn => 'PaPa Johns';

  static String get chicken => 'Chicken';

  static String get eggitem => 'Egg Item';

  static String get signin => 'Sign in';

  static String get welcometogofoods => 'Welcome to GoFoods!';

  static String get phonenumber => 'Phone Number';

  static String get enteryournumber => 'Enter Your Number';

  static String get password => 'Password';

  static String get facebook => 'Facebook';

  static String get apple => 'Apple';

  static String get donothaveaccount => 'Do not have an account?';

  static String get signup => 'Sign up';

  static String get remember => 'Remember me';

  static String get fanme => 'Full Name';

  static String get enteryourfullname => 'Enter Your Full Name';

  static String get emailadress => 'Email Address';

  static String get enteryouremail => 'Enter Your Email Address';

  static String get phonenumbers => 'Phone Number';

  static String get enteryourphonenumbers => 'Enter Your Phone Number';

  static String get deliveryadd => 'Delivery Address';

  static String get add1 => 'Puraton Custom, Chhatak';

  static String get add2 => 'Thana Ghata Road, Chhatak';

  static String get add3 => 'Dhak Bangla Road, Chhatak';

  static String get add4 => 'Bus Stand, Chhatak';

  static String get road => '216/C East Road';
}
